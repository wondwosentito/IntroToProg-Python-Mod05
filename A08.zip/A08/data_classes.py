# ------------------------------------------------------------------------------------------------- #
# Title: data_classes.py
# Description: Data classes for the Employee Ratings application
# ChangeLog: (Who, When, What)
# WPaulos, 03/16/2026, Created Person and Employee classes
# ------------------------------------------------------------------------------------------------- #

from datetime import date


class Person:
    """
    A class representing person data.

    Properties:
    - first_name (str): The person's first name.
    - last_name (str): The person's last name.
    """

    def __init__(self, first_name: str = "", last_name: str = ""):
        self.first_name = first_name
        self.last_name = last_name

    @property
    def first_name(self) -> str:
        """Gets the first name."""
        return self.__first_name.title()

    @first_name.setter
    def first_name(self, value: str):
        """Sets the first name with validation."""
        if value.isalpha() or value == "":
            self.__first_name = value
        else:
            raise ValueError("The first name should not contain numbers.")

    @property
    def last_name(self) -> str:
        """Gets the last name."""
        return self.__last_name.title()

    @last_name.setter
    def last_name(self, value: str):
        """Sets the last name with validation."""
        if value.isalpha() or value == "":
            self.__last_name = value
        else:
            raise ValueError("The last name should not contain numbers.")

    def __str__(self) -> str:
        """Returns person data as comma-separated values."""
        return f"{self.first_name},{self.last_name}"


class Employee(Person):
    """
    A class representing employee review data.

    Properties:
    - first_name (str): The employee's first name.
    - last_name (str): The employee's last name.
    - review_date (str): The employee review date in YYYY-MM-DD format.
    - review_rating (int): The review rating from 1 to 5.
    """

    def __init__(
        self,
        first_name: str = "",
        last_name: str = "",
        review_date: str = "1900-01-01",
        review_rating: int = 3
    ):
        super().__init__(first_name=first_name, last_name=last_name)
        self.review_date = review_date
        self.review_rating = review_rating

    @property
    def review_date(self) -> str:
        """Gets the review date."""
        return self.__review_date

    @review_date.setter
    def review_date(self, value: str):
        """Sets the review date with validation."""
        try:
            date.fromisoformat(value)
            self.__review_date = value
        except ValueError:
            raise ValueError("Incorrect date format, should be YYYY-MM-DD")

    @property
    def review_rating(self) -> int:
        """Gets the review rating."""
        return self.__review_rating

    @review_rating.setter
    def review_rating(self, value: int):
        """Sets the review rating with validation."""
        if value in (1, 2, 3, 4, 5):
            self.__review_rating = value
        else:
            raise ValueError("Please choose only values 1 through 5")

    def __str__(self) -> str:
        """Returns employee data as comma-separated values."""
        return f"{self.first_name},{self.last_name},{self.review_date},{self.review_rating}"
    
