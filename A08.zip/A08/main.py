# ------------------------------------------------------------------------------------------------- #
# Title: main.py
# Description: Main program for the Employee Ratings application
# ChangeLog: (Who, When, What)
# WPaulos, 03/16/2026, Created main program
# ------------------------------------------------------------------------------------------------- #

from data_classes import Employee
from processing_classes import FileProcessor
from presentation_classes import IO

FILE_NAME: str = "EmployeeRatings.json"

MENU: str = '''
---- Employee Ratings ------------------------------
  Select from the following menu:
    1. Show current employee rating data.
    2. Enter new employee rating data.
    3. Save data to a file.
    4. Exit the program.
--------------------------------------------------
'''

employees: list = []  # a table of employee data
menu_choice = ''

# Beginning of the main body of this script
employees = FileProcessor.read_employee_data_from_file(
    file_name=FILE_NAME,
    employee_data=employees,
    employee_type=Employee
)

while True:
    IO.output_menu(menu=MENU)
    menu_choice = IO.input_menu_choice()

    if menu_choice == "1":
        try:
            IO.output_employee_data(employee_data=employees)
        except Exception as e:
            IO.output_error_messages("There was a problem displaying the data.", e)
        continue

    elif menu_choice == "2":
        try:
            employees = IO.input_employee_data(
                employee_data=employees,
                employee_type=Employee
            )
            IO.output_employee_data(employee_data=employees)
        except Exception as e:
            IO.output_error_messages("There was a problem entering the data.", e)
        continue

    elif menu_choice == "3":
        try:
            FileProcessor.write_employee_data_to_file(
                file_name=FILE_NAME,
                employee_data=employees
            )
            print(f"Data was saved to the {FILE_NAME} file.")
        except Exception as e:
            IO.output_error_messages("There was a problem saving the file.", e)
        continue

    elif menu_choice == "4":
        break

    else:
        print("Please only choose option 1, 2, 3, or 4")

print("Program Ended")

from data_classes import Employee
from processing_classes import FileProcessor
from presentation_classes import IO

