# ------------------------------------------------------------------------------------------------- #
# Title: presentation_classes.py
# Description: Presentation classes for the Employee Ratings application
# ChangeLog: (Who, When, What)
# WPaulos, 03/16/2026, Created IO class
# ------------------------------------------------------------------------------------------------- #

from data_classes import Employee


class IO:
    """
    A collection of presentation layer functions that manage user input and output.
    """

    @staticmethod
    def output_error_messages(message: str, error: Exception = None):
        """
        Displays a custom error message to the user.

        :param message: Message text to display.
        :param error: Optional exception object.
        :return: None
        """
        print(message, end="\n\n")
        if error is not None:
            print("-- Technical Error Message -- ")
            print(error, error.__doc__, type(error), sep='\n')

    @staticmethod
    def output_menu(menu: str):
        """
        Displays the menu of choices to the user.

        :param menu: Menu text.
        :return: None
        """
        print()
        print(menu)
        print()

    @staticmethod
    def input_menu_choice():
        """
        Gets a menu choice from the user.

        :return: A string containing the user's menu choice.
        """
        choice = "0"
        try:
            choice = input("Enter your menu choice number: ")
            if choice not in ("1", "2", "3", "4"):
                raise Exception("Please choose only 1, 2, 3, or 4")
        except Exception as e:
            IO.output_error_messages(e.__str__())
        return choice

    @staticmethod
    def output_employee_data(employee_data: list):
        """
        Displays employee review data to the user.

        :param employee_data: List of Employee objects.
        :return: None
        """
        print()
        print("-" * 50)
        for employee in employee_data:
            if employee.review_rating == 5:
                message = "{} {} was reviewed on {} and is rated 5 (Leading)"
            elif employee.review_rating == 4:
                message = "{} {} was reviewed on {} and is rated 4 (Strong)"
            elif employee.review_rating == 3:
                message = "{} {} was reviewed on {} and is rated 3 (Solid)"
            elif employee.review_rating == 2:
                message = "{} {} was reviewed on {} and is rated 2 (Building)"
            elif employee.review_rating == 1:
                message = "{} {} was reviewed on {} and is rated 1 (Not Meeting Expectations)"
            else:
                message = "{} {} was reviewed on {} and has an unknown rating"

            print(message.format(employee.first_name, employee.last_name, employee.review_date))
        print("-" * 50)
        print()

    @staticmethod
    def input_employee_data(employee_data: list, employee_type: object):
        """
        Gets employee review data from the user.

        :param employee_data: List of Employee objects to append to.
        :param employee_type: A reference to the Employee class.
        :return: Updated list of Employee objects.
        """
        try:
            employee_object = employee_type()

            employee_object.first_name = input("What is the employee's first name? ")
            employee_object.last_name = input("What is the employee's last name? ")
            employee_object.review_date = input("What is their review date (YYYY-MM-DD)? ")
            employee_object.review_rating = int(input("What is their review rating (1-5)? "))

            employee_data.append(employee_object)

        except ValueError as e:
            IO.output_error_messages("That value is not the correct type of data!", e)
        except Exception as e:
            IO.output_error_messages("There was a non-specific error!", e)

        return employee_data
