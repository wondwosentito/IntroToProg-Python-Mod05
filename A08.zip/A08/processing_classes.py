# ------------------------------------------------------------------------------------------------- #
# Title: processing_classes.py
# Description: Processing classes for the Employee Ratings application
# ChangeLog: (Who, When, What)
# WPaulos, 03/16/2026, Created FileProcessor class
# ------------------------------------------------------------------------------------------------- #

import json
from data_classes import Employee


class FileProcessor:
    """
    A collection of processing layer functions that work with JSON files.
    """

    @staticmethod
    def read_employee_data_from_file(file_name: str, employee_data: list, employee_type: object):
        """
        Reads employee data from a JSON file into a list of Employee objects.

        :param file_name: Name of the file to read.
        :param employee_data: List to fill with Employee objects.
        :param employee_type: A reference to the Employee class.
        :return: A list of Employee objects.
        """
        from presentation_classes import IO

        try:
            with open(file_name, "r") as file:
                list_of_dictionary_data = json.load(file)
                for employee in list_of_dictionary_data:
                    employee_object = employee_type()
                    employee_object.first_name = employee["FirstName"]
                    employee_object.last_name = employee["LastName"]
                    employee_object.review_date = employee["ReviewDate"]
                    employee_object.review_rating = employee["ReviewRating"]
                    employee_data.append(employee_object)
        except FileNotFoundError as e:
            IO.output_error_messages(
                message="Error: The employee data file was not found.",
                error=e
            )
        except json.JSONDecodeError as e:
            IO.output_error_messages(
                message="Error: The file does not contain valid JSON data.",
                error=e
            )
        except Exception as e:
            IO.output_error_messages(
                message="Error: There was a problem reading the file.",
                error=e
            )
        return employee_data

    @staticmethod
    def write_employee_data_to_file(file_name: str, employee_data: list):
        """
        Writes employee data from a list of Employee objects to a JSON file.

        :param file_name: Name of the file to write to.
        :param employee_data: List of Employee objects.
        :return: None
        """
        from presentation_classes import IO

        try:
            list_of_dictionary_data: list = []

            for employee in employee_data:
                employee_json: dict = {
                    "FirstName": employee.first_name,
                    "LastName": employee.last_name,
                    "ReviewDate": employee.review_date,
                    "ReviewRating": employee.review_rating
                }
                list_of_dictionary_data.append(employee_json)

            with open(file_name, "w") as file:
                json.dump(list_of_dictionary_data, file, indent=2)

        except TypeError as e:
            IO.output_error_messages(
                message="Error: Please check that the data is valid JSON format.",
                error=e
            )
        except PermissionError as e:
            IO.output_error_messages(
                message="Error: Please check the data file's read/write permission.",
                error=e
            )
        except Exception as e:
            IO.output_error_messages(
                message="Error: There was a problem writing to the file.",
                error=e
            )