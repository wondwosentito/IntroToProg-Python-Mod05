# ------------------------------------------------------------------------------------------------- #
# Title: test_data_classes.py
# Description: Test script for data classes
# ChangeLog: (Who, When, What)
# WPaulos, 03/16/2026, Created test file for data classes
# ------------------------------------------------------------------------------------------------- #

from data_classes import Person, Employee

try:
    p = Person("Wan", "Paulos")
    print(p)

    e = Employee("Helen", "Ayana", "2026-03-16", 5)
    print(e)

except Exception as ex:
    print("Error testing data classes")
    print(ex)
