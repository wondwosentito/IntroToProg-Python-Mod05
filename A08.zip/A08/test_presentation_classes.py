# ------------------------------------------------------------------------------------------------- #
# Title: test_presentation_classes.py
# Description: Test script for presentation classes
# ChangeLog: (Who, When, What)
# WPaulos, 03/16/2026, Created test file for presentation classes
# ------------------------------------------------------------------------------------------------- #

from data_classes import Employee
from presentation_classes import IO

MENU = '''
---- Employee Ratings ------------------------------
  Select from the following menu:
    1. Show current employee rating data.
    2. Enter new employee rating data.
    3. Save data to a file.
    4. Exit the program.
--------------------------------------------------
'''

employees = [
    Employee("Wan", "Paulos", "2026-03-16", 5),
    Employee("Helen", "Ayana", "2026-03-15", 3)
]

try:
    IO.output_menu(MENU)
    IO.output_employee_data(employees)

except Exception as ex:
    print("Error testing presentation classes")
    print(ex)
