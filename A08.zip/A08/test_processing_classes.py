# ------------------------------------------------------------------------------------------------- #
# Title: test_processing_classes.py
# Description: Test script for processing classes
# ChangeLog: (Who, When, What)
# WPaulos, 03/16/2026, Created test file for processing classes
# ------------------------------------------------------------------------------------------------- #

from data_classes import Employee
from processing_classes import FileProcessor

FILE_NAME = "EmployeeRatings.json"

employees = [
    Employee("Wan", "Paulos", "2026-03-16", 4),
    Employee("Helen", "Ayana", "2026-03-15", 5)
]

try:
    FileProcessor.write_employee_data_to_file(FILE_NAME, employees)
    print("Write test completed.")

    loaded_employees = []
    loaded_employees = FileProcessor.read_employee_data_from_file(
        FILE_NAME, loaded_employees, Employee
    )

    for employee in loaded_employees:
        print(employee)

except Exception as ex:
    print("Error testing processing classes")
    print(ex)
